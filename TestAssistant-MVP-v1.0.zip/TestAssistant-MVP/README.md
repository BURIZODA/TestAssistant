# Test Assistant — MVP v1.0

Версияи аввалини build-ready-и намунаи асосӣ.

## Дарун дорад
- Kotlin + Jetpack Compose
- Offline UI
- Liquid-glass inspired cards
- Китобхонаи тестҳо
- Импорти TXT аз Android file picker
- Формати `?. / + / -`
- Формати `@ / #$ / #`
- Multiple correct answers
- Test player
- Previous / Next
- Натиҷаи тест
- Retry / Back to library

## Қадами баъдӣ
Пас аз санҷиши MVP:
- timer
- random questions
- practice/exam
- question navigator
- bookmarks
- history
- Room persistence
- DOC/QST/QSZ import
- dark mode ва glass blur-и пурратар
