package com.example.testassistant

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.UUID

data class Answer(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val correct: Boolean
)

data class Question(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val answers: List<Answer>
)

data class Test(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val questions: List<Question>,
    val source: String = "TXT"
)

class AppViewModel : ViewModel() {
    var tests by mutableStateOf(listOf(defaultTest()))
        private set

    var selectedTest by mutableStateOf<Test?>(null)
        private set

    var questionIndex by mutableIntStateOf(0)
        private set

    var chosen by mutableStateOf<Map<String, Set<String>>>(emptyMap())
        private set

    var result by mutableStateOf<ResultData?>(null)
        private set

    fun openTest(test: Test) {
        selectedTest = test
        questionIndex = 0
        chosen = emptyMap()
        result = null
    }

    fun backToLibrary() {
        selectedTest = null
        result = null
    }

    fun toggleAnswer(answerId: String) {
        val test = selectedTest ?: return
        val q = test.questions[questionIndex]
        val old = chosen[q.id].orEmpty()
        val multiple = q.answers.count { it.correct } > 1
        val next = if (multiple) {
            if (answerId in old) old - answerId else old + answerId
        } else {
            if (answerId in old) emptySet() else setOf(answerId)
        }
        chosen = chosen + (q.id to next)
    }

    fun next() {
        val test = selectedTest ?: return
        if (questionIndex < test.questions.lastIndex) questionIndex++
        else finish()
    }

    fun previous() {
        if (questionIndex > 0) questionIndex--
    }

    private fun finish() {
        val test = selectedTest ?: return
        var correct = 0
        var wrong = 0
        var unanswered = 0

        for (q in test.questions) {
            val picked = chosen[q.id].orEmpty()
            val expected = q.answers.filter { it.correct }.map { it.id }.toSet()
            when {
                picked.isEmpty() -> unanswered++
                picked == expected -> correct++
                else -> wrong++
            }
        }
        result = ResultData(correct, wrong, unanswered)
    }

    fun importTxt(name: String, text: String) {
        val parsed = TxtParser.parse(name, text)
        if (parsed.questions.isNotEmpty()) tests = listOf(parsed) + tests
    }
}

data class ResultData(val correct: Int, val wrong: Int, val unanswered: Int)

object TxtParser {
    fun parse(name: String, text: String): Test {
        val normalized = text.replace("\r\n", "\n").replace("\r", "\n")
        val lines = normalized.lines()
        val blocks = mutableListOf<MutableList<String>>()
        var current: MutableList<String>? = null

        for (raw in lines) {
            val line = raw.trim()
            val questionLine = line.startsWith("?.") || line.startsWith("@")
            if (questionLine) {
                current?.let { if (it.isNotEmpty()) blocks += it }
                current = mutableListOf(line)
            } else if (current != null && line.isNotBlank()) {
                current!!.add(line)
            }
        }
        current?.let { if (it.isNotEmpty()) blocks += it }

        val questions = blocks.mapNotNull { block ->
            val first = block.first()
            val questionText = when {
                first.startsWith("?.") -> first.removePrefix("?.").trim()
                first.startsWith("@") -> first.removePrefix("@").trim()
                else -> ""
            }
            if (questionText.isBlank()) return@mapNotNull null

            val answers = block.drop(1).mapNotNull { line ->
                when {
                    line.startsWith("#$") -> Answer(text = line.removePrefix("#$").trim(), correct = true)
                    line.startsWith("+") -> Answer(text = line.removePrefix("+").trim(), correct = true)
                    line.startsWith("#") -> Answer(text = line.removePrefix("#").trim(), correct = false)
                    line.startsWith("-") -> Answer(text = line.removePrefix("-").trim(), correct = false)
                    else -> null
                }
            }
            if (answers.isEmpty()) null else Question(text = questionText, answers = answers)
        }

        return Test(
            title = name.substringBeforeLast('.').ifBlank { "Тести воридшуда" },
            questions = questions
        )
    }
}

private fun defaultTest() = TxtParser.parse(
    "Тести намунавӣ",
    """
    ?.Менеҷмент чист?
    + Раванди банақшагирӣ, ташкил, роҳбарӣ ва назорат
    - Истеҳсоли молҳо
    - Пардохти музди меҳнат
    - Таҳияи қонунҳо
    - Фурӯши маҳсулот

    ?.Вазифаи асосии менеҷмент кадом аст?
    + Ба даст овардани ҳадафҳои ташкилот
    - Баланд бардоштани нархҳо
    - Маҳдуд кардани истеҳсол
    - Рекламаи маҳсулот
    - Кам кардани хизматрасонӣ
    """.trimIndent()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TestAssistantApp() }
    }
}

@Composable
fun TestAssistantApp(vm: AppViewModel = viewModel()) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            background = Color(0xFFF2F5FA),
            primary = Color(0xFF3157D5)
        )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFFF9FBFF), Color(0xFFE8EDF7))
                    )
                )
        ) {
            when {
                vm.selectedTest != null && vm.result != null -> ResultScreen(vm)
                vm.selectedTest != null -> PlayerScreen(vm)
                else -> LibraryScreen(vm)
            }
        }
    }
}

@Composable
private fun GlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.66f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        content = content
    )
}

@Composable
private fun LibraryScreen(vm: AppViewModel) {
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        val resolver = (androidx.compose.ui.platform.LocalContext.current).contentResolver
        val text = resolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: return@rememberLauncherForActivityResult
        val name = uri.lastPathSegment ?: "test.txt"
        vm.importTxt(name, text)
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = { BottomNavigationBar() }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(28.dp))
            Text("Test Assistant", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Китобхонаи тестҳо", color = Color.Gray)

            Spacer(Modifier.height(18.dp))

            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("Тестҳои шумо", fontWeight = FontWeight.SemiBold)
                    Text("${vm.tests.size} тест", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { picker.launch(arrayOf("text/plain", "text/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FileOpen, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Ворид кардани TXT")
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(vm.tests) { test ->
                    GlassCard(
                        Modifier
                            .fillMaxWidth()
                            .clickable { vm.openTest(test) }
                    ) {
                        Column(Modifier.padding(20.dp)) {
                            Text(test.title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text("${test.questions.size} савол • ${test.source}")
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = { vm.openTest(test) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Оғози тест")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomNavigationBar() {
    NavigationBar(Modifier.alpha(0.94f)) {
        NavigationBarItem(true, {}, { Icon(Icons.Default.Home, null); Text("Асосӣ") })
        NavigationBarItem(false, {}, { Icon(Icons.Default.List, null); Text("Тестҳо") })
        NavigationBarItem(false, {}, { Icon(Icons.Default.Settings, null); Text("Танзимот") })
    }
}

@Composable
private fun PlayerScreen(vm: AppViewModel) {
    val test = vm.selectedTest ?: return
    val q = test.questions[vm.questionIndex]
    val selected = vm.chosen[q.id].orEmpty()

    Column(
        Modifier
            .fillMaxSize()
            .padding(18.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("${vm.questionIndex + 1} / ${test.questions.size}", fontWeight = FontWeight.Bold)
            Text("Машқ", color = Color.Gray)
        }

        LinearProgressIndicator(
            progress = { (vm.questionIndex + 1f) / test.questions.size },
            Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp)
        )

        GlassCard(Modifier.fillMaxWidth()) {
            Text(
                q.text,
                fontSize = 21.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(22.dp)
            )
        }

        Spacer(Modifier.height(14.dp))

        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(q.answers) { answer ->
                val checked = answer.id in selected
                Card(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.toggleAnswer(answer.id) },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (checked)
                            Color(0xFFDCE5FF)
                        else Color.White.copy(alpha = 0.68f)
                    )
                ) {
                    Row(
                        Modifier.padding(15.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = checked,
                            onCheckedChange = { vm.toggleAnswer(answer.id) }
                        )
                        Text(answer.text, Modifier.padding(start = 8.dp))
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OutlinedButton(
                enabled = vm.questionIndex > 0,
                onClick = vm::previous
            ) { Text("Қаблӣ") }

            Button(onClick = vm::next) {
                Text(
                    if (vm.questionIndex < test.questions.lastIndex)
                        "Баъдӣ"
                    else "Анҷом"
                )
            }
        }
    }
}

@Composable
private fun ResultScreen(vm: AppViewModel) {
    val result = vm.result ?: return
    val total = result.correct + result.wrong + result.unanswered
    val percent = if (total == 0) 0 else result.correct * 100 / total

    Column(
        Modifier
            .fillMaxSize()
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(60.dp))
        Text("Натиҷа", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))

        GlassCard(Modifier.fillMaxWidth()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(25.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("$percent%", fontSize = 56.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text("Дуруст: ${result.correct}")
                Text("Хато: ${result.wrong}")
                Text("Ҷавоб дода нашуд: ${result.unanswered}")
            }
        }

        Spacer(Modifier.height(20.dp))

        Button(onClick = {
            vm.selectedTest?.let(vm::openTest)
        }) {
            Text("Аз нав гузаштан")
        }

        Spacer(Modifier.height(10.dp))

        OutlinedButton(onClick = vm::backToLibrary) {
            Text("Ба китобхона")
        }
    }
}
